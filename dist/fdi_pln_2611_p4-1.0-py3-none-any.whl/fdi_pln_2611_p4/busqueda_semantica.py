from __future__ import annotations

from collections.abc import Callable

import numpy as np
import ollama

MODEL = "nomic-embed-text"
BATCH = 32


def _embed_batch(textos: list[str]) -> list[np.ndarray | None]:
    """Calcula embeddings normalizados para una lista de textos."""
    response = ollama.embed(model=MODEL, input=textos)
    result = []
    for emb in response.embeddings:
        vec = np.array(emb, dtype=np.float32)
        norma = np.linalg.norm(vec)
        result.append(None if norma == 0 else vec / norma)
    return result


def calcular_embeddings(parrafos: list[dict]) -> tuple[np.ndarray, np.ndarray]:
    """Calcula embeddings de todos los párrafos sin callback de progreso."""
    return calcular_embeddings_con_progreso(parrafos, None)


def calcular_embeddings_con_progreso(
    parrafos: list[dict], progreso_cb: Callable[[int, int], None] | None
) -> tuple[np.ndarray, np.ndarray]:
    """Calcula embeddings por lotes y notifica progreso opcionalmente."""
    ids = []
    embeddings = []
    n = len(parrafos)
    for i in range(0, n, BATCH):
        batch = parrafos[i : i + BATCH]
        textos = [p.get("text", p.get("texto", "")) for p in batch]
        vecs = _embed_batch(textos)
        for p, vec in zip(batch, vecs):
            if vec is not None:
                ids.append(p["index"])
                embeddings.append(vec)
        if progreso_cb is not None:
            progreso_cb(min(i + BATCH, n), n)
    return np.array(embeddings, dtype=np.float32), np.array(ids, dtype=np.int32)


def guardar_embeddings(
    path_emb: str, path_ids: str, embeddings: np.ndarray, ids: np.ndarray
) -> None:
    """Guarda embeddings e IDs en ficheros NPY."""
    np.save(path_emb, embeddings)
    np.save(path_ids, ids)


def cargar_embeddings(path_emb: str, path_ids: str) -> tuple[np.ndarray, np.ndarray]:
    """Carga embeddings e IDs desde ficheros NPY."""
    return np.load(path_emb), np.load(path_ids)


def buscar_semantica(
    query: str, embeddings: np.ndarray, ids: np.ndarray, top_k: int = 20
) -> list[tuple[int, float]]:
    """Devuelve los top-k chunks más similares a la consulta."""
    vecs = _embed_batch([query])
    vec = vecs[0]
    if vec is None:
        return []
    scores = embeddings @ vec
    indices = np.argsort(scores)[::-1][:top_k]
    return [(int(ids[i]), float(scores[i])) for i in indices]
